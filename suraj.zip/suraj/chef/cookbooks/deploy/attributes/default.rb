default[:data_dir] = "/var/www/html"
default[:ssl_dir] = "/etc/httpd/ssl"
default[:conf_dir] = "/etc/httpd/conf"
